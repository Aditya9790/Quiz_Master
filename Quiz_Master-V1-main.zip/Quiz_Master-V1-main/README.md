# 21f1004669
IITM App Dev 1 project

This appication is a Quiz Master application where a normal user can log in to the portal and attemp the quiz and his/her result will be stored and he/she will be able to statistics based on the score obtained.

The superuser or admin will be able to add new subjects or delete the existing the existing subject. Inside each subject admin can add add/edit/delete new chapters. Moreover the admin can also delete a existing user. 

**Steps to Run the Application**

1. Clone the repository
```git clone https://github.com/AdityaIITM9790/Quiz_Master-V1.git```

2. Change the directory
```cd Quiz_Master-V1```

3. Install the dependencies
```pip install -r requirements.txt```

4. Run the application
```python app.py```

Voila!! You are now ready to explore the application